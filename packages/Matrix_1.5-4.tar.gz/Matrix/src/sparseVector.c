#include <stdint.h> /* fixed-width integer types, e.g., int64_t */
#include "sparseVector.h"

#define _nspV_
#include "t_sparseVector.c"

#define _lspV_
#include "t_sparseVector.c"

#define _ispV_
#include "t_sparseVector.c"

#define _dspV_
#include "t_sparseVector.c"

#define _zspV_
#include "t_sparseVector.c"
